"""API REST del modelo de abandono. Arrancar con:  uvicorn app.main:app --reload"""
import json
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Literal

import joblib
import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

MODELOS = Path(__file__).resolve().parent.parent / "models"
STATIC = Path(__file__).resolve().parent / "static"
ml: dict = {}


@asynccontextmanager
async def lifespan(app: FastAPI):
    # El modelo se carga UNA sola vez, al arrancar (no en cada peticion)
    ml["modelo"] = joblib.load(MODELOS / "modelo.joblib")
    ml["meta"] = json.loads((MODELOS / "metadata.json").read_text(encoding="utf-8"))
    yield
    ml.clear()


app = FastAPI(title="API de abandono de socios", version="1.0", lifespan=lifespan)


class Socio(BaseModel):
    """Entrada validada: si algo esta fuera de rango, FastAPI responde 422."""

    visitas_mes: float = Field(ge=0, le=31, examples=[3])
    clases_grupales_mes: int = Field(ge=0, le=60, examples=[0])
    quejas_6m: int = Field(ge=0, le=50, examples=[2])
    cuota_mensual: float = Field(ge=30, le=400, examples=[79])
    meses_antiguedad: float = Field(ge=0, le=120, examples=[4])
    plan: Literal["Basico", "Estandar", "Premium"] = Field(examples=["Basico"])
    pago_automatico: Literal["Si", "No"] = Field(examples=["No"])


class Prediccion(BaseModel):
    abandona: bool
    probabilidad: float
    version_modelo: str


@app.get("/", include_in_schema=False)
def inicio():
    """Frontend: formulario para ingresar los datos y ver la prediccion."""
    return FileResponse(STATIC / "index.html")


@app.get("/health")
def health():
    """Chequeo de salud: lo usan Docker y las plataformas de despliegue."""
    return {"estado": "ok", "modelo_cargado": "modelo" in ml}


@app.get("/model-info")
def model_info():
    return ml["meta"]


@app.post("/predict", response_model=Prediccion)
def predict(socio: Socio):
    X = pd.DataFrame([socio.model_dump()])[ml["meta"]["variables"]]
    prob = float(ml["modelo"].predict_proba(X)[0, 1])
    return Prediccion(
        abandona=prob >= 0.5, probabilidad=round(prob, 3), version_modelo=ml["meta"]["version_modelo"]
    )


@app.post("/predict/lote", response_model=list[Prediccion])
def predict_lote(socios: list[Socio]):
    if not 0 < len(socios) <= 1000:
        raise HTTPException(status_code=422, detail="Envia entre 1 y 1000 socios")
    X = pd.DataFrame([s.model_dump() for s in socios])[ml["meta"]["variables"]]
    probs = ml["modelo"].predict_proba(X)[:, 1]
    v = ml["meta"]["version_modelo"]
    return [
        Prediccion(abandona=bool(p >= 0.5), probabilidad=round(float(p), 3), version_modelo=v)
        for p in probs
    ]
