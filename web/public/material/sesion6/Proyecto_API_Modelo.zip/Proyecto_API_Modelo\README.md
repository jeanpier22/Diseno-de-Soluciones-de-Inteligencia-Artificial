# API del modelo de abandono de socios

Proyecto para llevar un modelo entrenado a una API en **tres etapas**: local → ngrok → Docker.
Usa `data/gimnasio_socios.csv` (el dataset con errores de la Sesión 3): `train.py` lo limpia, entrena
y guarda el pipeline completo en `models/modelo.joblib`.

```
Proyecto_API_Modelo/
├── data/gimnasio_socios.csv     datos sucios de la Sesión 3
├── train.py                     limpieza + entrenamiento + métricas -> models/
├── app/main.py                  API FastAPI (/health, /model-info, /predict, /predict/lote)
├── tests/test_api.py            pruebas automáticas
├── peticiones.http              peticiones listas (extensión REST Client)
├── Dockerfile · docker-compose.yml
└── .vscode/                     tareas (Ctrl+Shift+P > Tasks: Run Task) y depuración (F5)
```

Extensiones de VS Code recomendadas: **Python**, **Docker**, **REST Client** (VS Code las sugiere al abrir la carpeta).

## Etapa 0 · Preparar el entorno (una vez)

```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements-dev.txt
python train.py                  # crea models/modelo.joblib y models/metadata.json
python -m pytest -v              # 5 pruebas deben pasar
```

## Etapa 1 · API en local

```powershell
uvicorn app.main:app --reload --port 8000
```

- Documentación interactiva (probar sin escribir código): http://localhost:8000/docs
- Salud: http://localhost:8000/health
- Con `peticiones.http` o con curl:

```bash
curl -X POST localhost:8000/predict -H "Content-Type: application/json" \
  -d '{"visitas_mes":2,"clases_grupales_mes":0,"quejas_6m":3,"cuota_mensual":79,"meses_antiguedad":3,"plan":"Basico","pago_automatico":"No"}'
# {"abandona":true,"probabilidad":0.882,"version_modelo":"1.0"}
```

Una entrada fuera de rango (por ejemplo `visitas_mes: 400`) responde **422**: la validación la hace Pydantic.

## Etapa 2 · Compartirla con ngrok

Con la API de la etapa 1 corriendo, en **otra terminal**:

```powershell
ngrok config add-authtoken <TU_TOKEN>   # solo la primera vez (cuenta gratuita en ngrok.com)
ngrok http 8000
```

ngrok muestra una URL como `https://xxxx.ngrok-free.app`. Cualquiera puede llamar a tu API local:
`https://xxxx.ngrok-free.app/docs`.

- La URL **cambia** cada vez que reinicias ngrok y deja de funcionar al cerrarlo.
- La API queda **pública y sin clave** mientras ngrok esté abierto: úsalo para probar y apágalo al terminar.
- Sirve para demostrar. Para algo estable, pasa a la etapa 3 y despliega la imagen.

## Etapa 3 · Docker

Requiere **Docker Desktop** abierto (en Windows, con WSL2).

```powershell
docker compose up --build        # construye la imagen y levanta la API en :8000
# o, sin compose:
docker build -t api-abandono:1.0 .
docker run -p 8000:8000 api-abandono:1.0
```

El `Dockerfile` tiene **dos etapas**: la primera entrena el modelo dentro de la imagen y la segunda copia
solo lo necesario para servirlo (no hace falta entrenar antes). Corre con un usuario sin privilegios y
trae `HEALTHCHECK` sobre `/health`.

```powershell
docker ps                        # la columna STATUS debe decir (healthy)
docker compose down              # apagar
```

Para desplegar la imagen en Render, Railway o Cloud Run, súbela a un registro (`docker push`) o conecta este
repositorio con el `Dockerfile` y la plataforma construye por ti.

## Problemas frecuentes

| Síntoma | Causa |
|---|---|
| `FileNotFoundError: models/modelo.joblib` | Falta correr `python train.py` (en Docker no hace falta) |
| El contenedor no responde desde fuera | Falta `--host 0.0.0.0` en el comando de arranque |
| Error al cargar el `.joblib` | Distinta versión de scikit-learn entre entrenar y servir: usa `requirements.txt` en ambos |
| `error during connect ... dockerDesktopLinuxEngine` | Docker Desktop no está abierto |
