const API = (window.API_URL || "").replace(/\/$/, "");
const $ = (id) => document.getElementById(id);

const EJEMPLOS = {
  riesgo: { visitas_mes: 2, clases_grupales_mes: 0, quejas_6m: 3, cuota_mensual: 79, meses_antiguedad: 3, plan: "Basico", pago_automatico: "No" },
  fiel: { visitas_mes: 18, clases_grupales_mes: 5, quejas_6m: 0, cuota_mensual: 119, meses_antiguedad: 24, plan: "Estandar", pago_automatico: "Si" },
};
const CAMPOS = Object.keys(EJEMPLOS.riesgo);

const NOMBRES = {
  visitas_mes: "Visitas al mes", clases_grupales_mes: "Clases grupales", quejas_6m: "Quejas (6 meses)",
  cuota_mensual: "Cuota mensual", meses_antiguedad: "Antigüedad", plan: "Plan", pago_automatico: "Pago automático",
};

function cargar(ej) { CAMPOS.forEach((k) => ($(k).value = ej[k])); }
cargar(EJEMPLOS.riesgo);

document.querySelectorAll("[data-ej]").forEach((b) =>
  b.addEventListener("click", () => { cargar(EJEMPLOS[b.dataset.ej]); $("form").requestSubmit(); })
);

$("form").addEventListener("submit", async (e) => {
  e.preventDefault();
  $("error").style.display = "none";
  const datos = {};
  CAMPOS.forEach((k) => { const el = $(k); datos[k] = el.tagName === "SELECT" ? el.value : Number(el.value); });
  try {
    const r = await fetch(API + "/predict", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(datos) });
    if (!r.ok) {
      const err = await r.json();
      const det = Array.isArray(err.detail) ? err.detail.map((d) => (NOMBRES[d.loc.slice(-1)[0]] || d.loc.slice(-1)[0]) + ": " + d.msg).join(" · ") : err.detail;
      throw new Error(det || "Error " + r.status);
    }
    mostrar(await r.json(), datos);
  } catch (ex) {
    $("error").textContent = "No se pudo predecir. " + ex.message;
    $("error").style.display = "block";
  }
});

function mostrar(p, datos) {
  const pct = Math.round(p.probabilidad * 1000) / 10;
  const color = pct >= 60 ? "var(--pink)" : pct >= 30 ? "var(--warn)" : "var(--ok)";
  const nivel = pct >= 60 ? "Riesgo alto" : pct >= 30 ? "Riesgo medio" : "Riesgo bajo";
  $("vacio").hidden = true;
  $("resultado").hidden = false;
  $("veredicto").textContent = p.abandona ? "Abandona" : "Se queda";
  $("veredicto").style.color = color;
  $("pct").textContent = "Probabilidad de abandono: " + pct.toString().replace(".", ",") + " %";
  $("relleno").style.width = pct + "%";
  $("relleno").style.background = color;
  $("nivel").textContent = nivel;
  $("nivel").style.background = color;
  $("version").textContent = "Modelo versión " + p.version_modelo + " · umbral de decisión: 50 %";

  // Factores: barras divergentes (rosa = empuja a abandonar, verde = a quedarse)
  const lista = $("factores");
  lista.replaceChildren();
  const max = Math.max(0.01, ...p.factores.map((f) => Math.abs(f.impacto)));
  p.factores.forEach((f) => {
    const li = document.createElement("li");
    const nombre = document.createElement("span");
    nombre.textContent = NOMBRES[f.variable] + " = " + valorLegible(f.variable, datos[f.variable]);
    const eje = document.createElement("div");
    eje.className = "eje";
    const barra = document.createElement("div");
    barra.className = "b " + (f.impacto >= 0 ? "alto" : "bajo");
    barra.style.width = (Math.abs(f.impacto) / max) * 50 + "%";
    barra.title = (f.impacto >= 0 ? "+" : "") + f.impacto.toFixed(2);
    eje.appendChild(barra);
    li.append(nombre, eje);
    lista.appendChild(li);
  });

  // Accion sugerida segun el nivel de riesgo y el factor principal
  const top = p.factores[0];
  const quien = NOMBRES[top.variable].toLowerCase();
  let texto;
  if (pct >= 60) texto = "Contactar al socio esta semana. Lo que más empuja el riesgo es: " + quien + ". Ofrecer una clase de prueba, atender sus quejas o proponer pago automático.";
  else if (pct >= 30) texto = "Mantenerlo en seguimiento. Un mensaje de motivación o una invitación a una clase grupal puede inclinar la balanza.";
  else texto = "Socio estable. Basta con mantener la relación habitual; no requiere acción especial.";
  const acc = $("accion");
  acc.replaceChildren();
  const b = document.createElement("b");
  b.textContent = "Acción sugerida: ";
  acc.append(b, document.createTextNode(texto));
}

function valorLegible(variable, v) {
  if (variable === "plan") return { Basico: "Básico", Estandar: "Estándar", Premium: "Premium" }[v];
  if (variable === "pago_automatico") return v === "Si" ? "Sí" : "No";
  return v;
}

// Métricas del modelo, leídas de la propia API
fetch(API + "/model-info")
  .then((r) => (r.ok ? r.json() : Promise.reject()))
  .then((m) => {
    $("m-version").textContent = m.version_modelo;
    $("m-acc").textContent = (m.metricas.accuracy * 100).toFixed(0) + " %";
    $("m-auc").textContent = m.metricas.roc_auc.toFixed(2).replace(".", ",");
    $("m-n").textContent = String(m.metricas.filas_entrenamiento).replace(/\B(?=(\d{3})+(?!\d))/g, " ");
    $("modelo-info").hidden = false;
  })
  .catch(() => {});
