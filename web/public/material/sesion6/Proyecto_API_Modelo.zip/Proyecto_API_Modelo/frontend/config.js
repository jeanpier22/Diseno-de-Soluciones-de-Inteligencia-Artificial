// Dirección de la API. Vacío = el mismo servidor que entrega esta página (local, ngrok o Docker).
// Si el frontend se aloja en otro dominio, pon aquí la URL de la API, por ejemplo:
//   window.API_URL = "https://mi-api.onrender.com";
// y en la API define la variable de entorno CORS_ORIGINS con el dominio del frontend.
window.API_URL = "";
