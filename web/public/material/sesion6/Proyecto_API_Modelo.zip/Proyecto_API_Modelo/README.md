# API del modelo de abandono de socios (backend + frontend)

Proyecto para llevar un modelo entrenado a una API en **tres etapas**: local → ngrok → Docker.
Usa `backend/data/gimnasio_socios.csv` (el dataset con errores de la Sesión 3): `train.py` lo limpia, entrena
y guarda el pipeline completo en `backend/models/modelo.joblib`.

```
Proyecto_API_Modelo/
├── backend/                     TODO lo que corre en el servidor
│   ├── app/main.py              API FastAPI (/health, /model-info, /predict, /predict/lote)
│   ├── train.py                 limpieza + entrenamiento + métricas -> models/
│   ├── data/gimnasio_socios.csv datos sucios de la Sesión 3
│   ├── models/                  modelo.joblib y metadata.json (los crea train.py)
│   ├── tests/test_api.py        pruebas automáticas
│   └── requirements*.txt
├── frontend/                    TODO lo que ve el usuario (HTML, CSS y JavaScript puros)
│   ├── index.html               el negocio, las 7 características y el formulario
│   ├── styles.css · app.js
│   ├── config.js                dirección de la API (vacía = el mismo servidor)
│   └── assets/                  ilustraciones del gimnasio (SVG)
├── Dockerfile · docker-compose.yml   empaquetan backend + frontend en una imagen
├── peticiones.http              peticiones listas (extensión REST Client)
└── .vscode/                     tareas (Ctrl+Shift+P > Tasks: Run Task) y depuración (F5)
```

**Cómo se conectan:** el frontend no tiene servidor propio. La API sirve la carpeta `frontend/` en la ruta `/`
y el formulario llama a `/predict` en el mismo servidor. Así, local, ngrok y Docker usan **una sola URL y un solo puerto**.
Si algún día alojas el frontend en otro dominio, cambia `frontend/config.js` y define `CORS_ORIGINS` en la API.

Extensiones de VS Code recomendadas: **Python**, **Docker**, **REST Client** (VS Code las sugiere al abrir la carpeta).

## Etapa 0 · Preparar el entorno (una vez)

```powershell
python -m venv .venv
.venv\Scripts\activate
cd backend
pip install -r requirements-dev.txt
python train.py                  # crea models/modelo.joblib y models/metadata.json
python -m pytest -v              # 8 pruebas deben pasar
```

## Etapa 1 · API + frontend en local

Desde la carpeta `backend/`:

```powershell
uvicorn app.main:app --reload --port 8000
```

- **Frontend (formulario):** http://localhost:8000/
- Documentación interactiva de la API: http://localhost:8000/docs
- Salud: http://localhost:8000/health

```bash
curl -X POST localhost:8000/predict -H "Content-Type: application/json" \
  -d '{"visitas_mes":2,"clases_grupales_mes":0,"quejas_6m":3,"cuota_mensual":79,"meses_antiguedad":3,"plan":"Basico","pago_automatico":"No"}'
# {"abandona":true,"probabilidad":0.882,"version_modelo":"1.0","factores":[...]}
```

La respuesta incluye `factores`: cuánto empuja cada dato la predicción respecto de un socio promedio
(positivo = hacia abandonar, negativo = hacia quedarse). El frontend los dibuja como barras.
Una entrada fuera de rango (por ejemplo `visitas_mes: 400`) responde **422**.

## Etapa 2 · Compartirla con ngrok

Con la API de la etapa 1 corriendo, en **otra terminal**:

```powershell
ngrok config add-authtoken <TU_TOKEN>   # solo la primera vez (cuenta gratuita en ngrok.com)
ngrok http 8000
```

Abre la URL `https://xxxx.ngrok-free.app` (formulario) o `https://xxxx.ngrok-free.app/docs`.

- La URL **cambia** cada vez que reinicias ngrok y deja de funcionar al cerrarlo.
- La API queda **pública y sin clave** mientras ngrok esté abierto: úsalo para probar y apágalo al terminar.

## Etapa 3 · Docker

Requiere **Docker Desktop** abierto (en Windows, con WSL2). Desde la **raíz** del proyecto:

```powershell
docker compose up --build        # construye la imagen y levanta todo en :8000
# o, sin compose:
docker build -t api-abandono:1.0 .
docker run -p 8000:8000 api-abandono:1.0
```

El `Dockerfile` tiene **dos etapas**: la primera entrena el modelo dentro de la imagen y la segunda copia
solo lo necesario para servirlo (`backend/app`, el modelo y `frontend/`). No hace falta entrenar antes.
Corre con un usuario sin privilegios y trae `HEALTHCHECK` sobre `/health`.

```powershell
docker ps                        # la columna STATUS debe decir (healthy)
docker compose down              # apagar
```

## Problemas frecuentes

| Síntoma | Causa |
|---|---|
| `Error loading ASGI app` / `No module named app` | Estás fuera de `backend/`: `cd backend` antes de `uvicorn` |
| `FileNotFoundError: models/modelo.joblib` | Falta correr `python train.py` (en Docker no hace falta) |
| La página sale sin diseño o sin imágenes | La carpeta `frontend/` no está junto a `backend/` |
| El contenedor no responde desde fuera | Falta `--host 0.0.0.0` en el comando de arranque |
| Error al cargar el `.joblib` | Distinta versión de scikit-learn entre entrenar y servir |
| `error during connect ... dockerDesktopLinuxEngine` | Docker Desktop no está abierto |
