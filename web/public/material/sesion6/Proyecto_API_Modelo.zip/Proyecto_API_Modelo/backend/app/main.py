"""API REST del modelo de abandono (backend).

Arrancar desde la carpeta backend/:   uvicorn app.main:app --reload
Las rutas de la API van primero; al final se monta la carpeta frontend/ para servir el formulario.
"""
import json
import os
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Literal

import joblib
import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

BACKEND = Path(__file__).resolve().parent.parent
MODELOS = BACKEND / "models"
# Local: ../frontend  |  Docker: /srv/frontend (se fija con la variable FRONTEND_DIR)
FRONTEND = Path(os.getenv("FRONTEND_DIR", BACKEND.parent / "frontend"))
ml: dict = {}


@asynccontextmanager
async def lifespan(app: FastAPI):
    # El modelo se carga UNA sola vez, al arrancar (no en cada peticion)
    ml["modelo"] = joblib.load(MODELOS / "modelo.joblib")
    ml["meta"] = json.loads((MODELOS / "metadata.json").read_text(encoding="utf-8"))
    yield
    ml.clear()


app = FastAPI(title="API de abandono de socios", version="1.1", lifespan=lifespan)

# Solo hace falta si el frontend se aloja en OTRO dominio. Ej.: CORS_ORIGINS=https://mi-front.com
_origenes = [o.strip() for o in os.getenv("CORS_ORIGINS", "").split(",") if o.strip()]
if _origenes:
    app.add_middleware(CORSMiddleware, allow_origins=_origenes, allow_methods=["*"], allow_headers=["*"])


class Socio(BaseModel):
    """Entrada validada: si algo esta fuera de rango, FastAPI responde 422."""

    visitas_mes: float = Field(ge=0, le=31, examples=[3])
    clases_grupales_mes: int = Field(ge=0, le=60, examples=[0])
    quejas_6m: int = Field(ge=0, le=50, examples=[2])
    cuota_mensual: float = Field(ge=30, le=400, examples=[79])
    meses_antiguedad: float = Field(ge=0, le=120, examples=[4])
    plan: Literal["Basico", "Estandar", "Premium"] = Field(examples=["Basico"])
    pago_automatico: Literal["Si", "No"] = Field(examples=["No"])


class Factor(BaseModel):
    variable: str
    impacto: float  # > 0 empuja hacia "abandona"; < 0 empuja hacia "se queda"


class Prediccion(BaseModel):
    abandona: bool
    probabilidad: float
    version_modelo: str
    factores: list[Factor] = []


def _factores(X: pd.DataFrame) -> list[Factor]:
    """Cuanto empuja cada variable la prediccion respecto de un socio promedio (log-odds)."""
    pipe = ml["modelo"]
    pre, clf = pipe.named_steps["pre"], pipe.named_steps["modelo"]
    Xt = pre.transform(X)
    Xt = (Xt.toarray() if hasattr(Xt, "toarray") else Xt)[0]
    medias = ml["meta"].get("medias_transformadas", {})
    variables = ml["meta"]["variables"]
    total: dict[str, float] = {v: 0.0 for v in variables}
    for nombre, valor, coef in zip(pre.get_feature_names_out(), Xt, clf.coef_[0]):
        columna = nombre.split("__", 1)[1]
        origen = next(v for v in variables if columna == v or columna.startswith(v + "_"))
        total[origen] += (valor - medias.get(nombre, 0.0)) * coef
    return sorted((Factor(variable=v, impacto=round(i, 3)) for v, i in total.items()),
                  key=lambda f: -abs(f.impacto))


@app.get("/health")
def health():
    """Chequeo de salud: lo usan Docker y las plataformas de despliegue."""
    return {"estado": "ok", "modelo_cargado": "modelo" in ml}


@app.get("/model-info")
def model_info():
    """Version, variables y metricas del modelo (sin los datos internos de explicacion)."""
    return {k: v for k, v in ml["meta"].items() if k != "medias_transformadas"}


@app.post("/predict", response_model=Prediccion)
def predict(socio: Socio):
    X = pd.DataFrame([socio.model_dump()])[ml["meta"]["variables"]]
    prob = float(ml["modelo"].predict_proba(X)[0, 1])
    return Prediccion(
        abandona=prob >= 0.5,
        probabilidad=round(prob, 3),
        version_modelo=ml["meta"]["version_modelo"],
        factores=_factores(X),
    )


@app.post("/predict/lote", response_model=list[Prediccion])
def predict_lote(socios: list[Socio]):
    if not 0 < len(socios) <= 1000:
        raise HTTPException(status_code=422, detail="Envia entre 1 y 1000 socios")
    X = pd.DataFrame([s.model_dump() for s in socios])[ml["meta"]["variables"]]
    probs = ml["modelo"].predict_proba(X)[:, 1]
    v = ml["meta"]["version_modelo"]
    return [
        Prediccion(abandona=bool(p >= 0.5), probabilidad=round(float(p), 3), version_modelo=v)
        for p in probs
    ]


# Al final: sirve frontend/ en "/" (index.html, styles.css, app.js, assets/). Las rutas de arriba tienen prioridad.
if FRONTEND.exists():
    app.mount("/", StaticFiles(directory=FRONTEND, html=True), name="frontend")
