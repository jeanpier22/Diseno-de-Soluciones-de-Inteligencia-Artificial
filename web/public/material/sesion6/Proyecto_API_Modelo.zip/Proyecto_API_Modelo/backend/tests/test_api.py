from fastapi.testclient import TestClient

from app.main import app

SOCIO = {
    "visitas_mes": 3, "clases_grupales_mes": 0, "quejas_6m": 2, "cuota_mensual": 79,
    "meses_antiguedad": 4, "plan": "Basico", "pago_automatico": "No",
}


def test_health():
    with TestClient(app) as c:
        r = c.get("/health")
        assert r.status_code == 200 and r.json()["modelo_cargado"] is True


def test_predict_devuelve_probabilidad():
    with TestClient(app) as c:
        r = c.post("/predict", json=SOCIO)
        assert r.status_code == 200
        assert 0 <= r.json()["probabilidad"] <= 1


def test_socio_fiel_tiene_menos_riesgo_que_socio_inactivo():
    fiel = {**SOCIO, "visitas_mes": 20, "clases_grupales_mes": 6, "quejas_6m": 0, "pago_automatico": "Si"}
    with TestClient(app) as c:
        p_fiel = c.post("/predict", json=fiel).json()["probabilidad"]
        p_inactivo = c.post("/predict", json=SOCIO).json()["probabilidad"]
    assert p_fiel < p_inactivo


def test_entrada_invalida_da_422():
    with TestClient(app) as c:
        assert c.post("/predict", json={**SOCIO, "visitas_mes": 400}).status_code == 422
        assert c.post("/predict", json={**SOCIO, "plan": "Oro"}).status_code == 422


def test_lote():
    with TestClient(app) as c:
        r = c.post("/predict/lote", json=[SOCIO, SOCIO])
        assert r.status_code == 200 and len(r.json()) == 2


def test_frontend_se_sirve_en_la_raiz():
    with TestClient(app) as c:
        r = c.get("/")
        assert r.status_code == 200 and "text/html" in r.headers["content-type"]
        assert "Predecir" in r.text


def test_factores_explican_la_prediccion():
    with TestClient(app) as c:
        f = c.post("/predict", json=SOCIO).json()["factores"]
        assert len(f) == 7
        assert {x["variable"] for x in f} == {
            "visitas_mes", "clases_grupales_mes", "quejas_6m", "cuota_mensual",
            "meses_antiguedad", "plan", "pago_automatico"}
        # pocas visitas empujan hacia abandonar
        assert next(x for x in f if x["variable"] == "visitas_mes")["impacto"] > 0


def test_frontend_y_assets():
    with TestClient(app) as c:
        for ruta in ("/", "/styles.css", "/app.js", "/assets/hero-gimnasio.svg"):
            assert c.get(ruta).status_code == 200, ruta
        assert c.get("/docs").status_code == 200  # la API sigue teniendo prioridad
