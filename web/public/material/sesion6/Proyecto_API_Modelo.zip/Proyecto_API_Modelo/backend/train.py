"""Entrena el modelo de abandono de socios y lo guarda en models/.

Uso:  python train.py
Hace todo el flujo: limpieza (Sesion 3) -> pipeline -> metricas -> modelo.joblib
"""
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import sklearn
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

RAIZ = Path(__file__).parent
DATOS = RAIZ / "data" / "gimnasio_socios.csv"
SALIDA = RAIZ / "models"

NUMERICAS = ["visitas_mes", "clases_grupales_mes", "quejas_6m", "cuota_mensual", "meses_antiguedad"]
CATEGORICAS = ["plan", "pago_automatico"]
OBJETIVO = "abandono"

# Rangos validos: lo que cae fuera es un error de captura y se convierte en nulo
RANGOS = {"visitas_mes": (0, 31), "cuota_mensual": (30, 400), "meses_antiguedad": (0, 120)}


def limpiar(df: pd.DataFrame) -> pd.DataFrame:
    """Aplica la limpieza de la Sesion 3 a gimnasio_socios.csv."""
    df = df.drop_duplicates(subset="id_socio").copy()

    # Inconsistencias de texto
    df["plan"] = (
        df["plan"].str.strip().str.lower().str.replace("á", "a").str.replace("é", "e")
        .map({"basico": "Basico", "estandar": "Estandar", "premium": "Premium"})
    )
    df["pago_automatico"] = (
        df["pago_automatico"].str.strip().str.lower()
        .map({"si": "Si", "sí": "Si", "s": "Si", "no": "No", "n": "No"})
    )

    # Tipos de dato: "S/ 119" -> 119.0
    df["cuota_mensual"] = pd.to_numeric(
        df["cuota_mensual"].astype(str).str.replace("S/", "", regex=False).str.strip(),
        errors="coerce",
    )

    # Valores imposibles -> nulo (se imputan despues, dentro del pipeline)
    for col, (lo, hi) in RANGOS.items():
        df.loc[~df[col].between(lo, hi), col] = np.nan
    return df


def construir_pipeline() -> Pipeline:
    """Imputacion + escalado + one-hot + regresion logistica en un solo objeto."""
    pre = ColumnTransformer([
        ("num", Pipeline([("imp", SimpleImputer(strategy="median")), ("sc", StandardScaler())]), NUMERICAS),
        ("cat", Pipeline([("imp", SimpleImputer(strategy="most_frequent")),
                          ("oh", OneHotEncoder(handle_unknown="ignore"))]), CATEGORICAS),
    ])
    return Pipeline([("pre", pre), ("modelo", LogisticRegression(max_iter=1000))])


def main() -> None:
    df = limpiar(pd.read_csv(DATOS))
    X, y = df[NUMERICAS + CATEGORICAS], df[OBJETIVO]
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)

    pipe = construir_pipeline().fit(X_tr, y_tr)
    pred, prob = pipe.predict(X_te), pipe.predict_proba(X_te)[:, 1]
    metricas = {
        "accuracy": round(float(accuracy_score(y_te, pred)), 4),
        "roc_auc": round(float(roc_auc_score(y_te, prob)), 4),
        "matriz_confusion": confusion_matrix(y_te, pred).tolist(),
        "filas_entrenamiento": int(len(X_tr)),
    }

    # Promedios de las variables ya transformadas: la API los usa para explicar cuanto empuja
    # cada dato la prediccion respecto de un socio "promedio"
    Xt = pipe.named_steps["pre"].transform(X_tr)
    Xt = Xt.toarray() if hasattr(Xt, "toarray") else np.asarray(Xt)
    medias = dict(zip(pipe.named_steps["pre"].get_feature_names_out().tolist(),
                      np.round(Xt.mean(axis=0), 6).tolist()))

    SALIDA.mkdir(exist_ok=True)
    joblib.dump(pipe, SALIDA / "modelo.joblib")
    meta = {
        "version_modelo": "1.0",
        "sklearn": sklearn.__version__,
        "variables": NUMERICAS + CATEGORICAS,
        "metricas": metricas,
        "medias_transformadas": medias,
    }
    (SALIDA / "metadata.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    print(json.dumps(meta, indent=2))


if __name__ == "__main__":
    main()
